import http.server
import os

PORT = 80
FLAG = os.environ.get("FLAG")

def get_mime_type(filename):
    if filename.endswith(".html"):
        return "text/html"
    elif filename.endswith(".css"):
        return "text/css"
    elif filename.endswith(".js"):
        return "application/javascript"
    elif filename.endswith(".png"):
        return "image/png"
    elif filename.endswith(".jpg") or filename.endswith(".jpeg"):
        return "image/jpeg"
    elif filename.endswith(".gif"):
        return "image/gif"
    else:
        return "application/octet-stream"

class Handler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path.startswith("/api/"):
            api_route = self.path[len("/api/"):]
            if api_route == "status":
                self.send_response(200)
                self.send_header("Content-type", "application/json")
                self.end_headers()
                self.wfile.write(b'{"status": "ok"}')
                return
            if api_route == "flag":
                if not FLAG:
                    self.send_response(500)
                    self.end_headers()
                    self.wfile.write(b'{"error": "FLAG not set"}')
                    return

                self.send_response(200)
                self.send_header("Content-type", "application/json")
                self.end_headers()
                self.wfile.write(b'{"flag": "' + FLAG.encode() + b'"}')
                return

        # Serve files from /static
        filepath = os.path.join("static", self.path.lstrip("/"))

        if not os.path.isfile(filepath):
            filepath = os.path.join("static", "index.html")

        if os.path.isfile(filepath):
            self.send_response(200)
            self.send_header("Content-type", get_mime_type(filepath))
            self.end_headers()
            with open(filepath, "rb") as f:
                self.wfile.write(f.read())
                return
        
        self.send_response(404)
        self.end_headers()
        self.wfile.write(b"File not found")

with http.server.ThreadingHTTPServer(("", PORT), Handler) as httpd:
    print(f"Serving at port {PORT}")
    httpd.serve_forever()